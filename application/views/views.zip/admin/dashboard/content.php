
<header class="page-header">
	<h2>Dashboard</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="index.html">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Dashboard</span></li>
		</ol>
		&nbsp;
	</div>
</header>

<section class="panel">
	<div class="panel-body">
		Selamat Datang di Halaman Dashboard.
	</div>
</section>