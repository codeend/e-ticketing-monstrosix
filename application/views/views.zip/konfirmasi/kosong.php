<div class="row">
    <div class="col-md-12">
        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                </div>
                <h2 class="panel-title">Konfirmasi</h2>
            </header>
            <div class="panel-body">
                <div class="alert alert-danger fade in nomargin">
                    <h4>Bukti Pembayaran Kosong</h4>
                </div>
            </div>
        </section>
    </div>
</div>