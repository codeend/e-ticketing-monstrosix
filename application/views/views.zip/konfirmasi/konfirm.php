<div class="row">
    <div class="col-md-12">
        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                </div>
                <h2 class="panel-title">Konfirmasi</h2>
            </header>
            <div class="panel-body">
                <div class="alert alert-info fade in nomargin">
                    <h4>Terimakasih</h4>
                    <p>Kami akan melakukan pengecakan. Tiket akan kami kirim VIA EMAIL.</p>
                </div>
            </div>
        </section>
    </div>
</div>